
import os
from flask import Flask, app
from datetime import timedelta
from flask_jwt_extended import JWTManager
from pymongo import MongoClient
from dotenv import load_dotenv
app = Flask(__name__)
load_dotenv()
app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY')
PORT = int(os.getenv('FLASK_PORT', 8003))
MONGO_URI = os.getenv('MONGO_URI')
try:
    client = MongoClient(os.getenv("MONGO_URI"), serverSelectionTimeoutMS=2000)
    client.server_info()  # fuerza chequeo
    db = client["flask_jwt_db"]
    juguetes_col = db["juguetes"]
    usuarios_col = db["usuarios"]
    print("Conectado correctamente a MongoDB")
except Exception as e:
    print("No se pudo conectar a MongoDB:", e)
    client = None
    db = None
    juguetes_col = None
    usuarios_col = None
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=1)
jwt = JWTManager(app)