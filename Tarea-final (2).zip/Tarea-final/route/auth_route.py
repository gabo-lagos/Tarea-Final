from flask import jsonify, request
from flask_jwt_extended import jwt_required, get_jwt, create_access_token, jwt
from tarea_app import generate_password_hash, check_password_hash, app, users

def role_required(allowed_roles):
    def wrapper(fn):
        @jwt_required()
        def decorator(*args, **kwargs):
            claims = get_jwt()
            role = claims.get('role')
            if role not in allowed_roles:
                return jsonify({"msg": "El usuario no tiene el rol requerido"}), 403
            return fn(*args, **kwargs)
        decorator.__name__ = fn.__name__
        return decorator
    return wrapper
@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    if not data or 'username' not in data or 'password' not in data:
        return jsonify({"msg": "Falta nombre de usuario o contraseña"}), 400

    username = data['username']
    password = data['password']
    user = users.get(username)
    if not user or not check_password_hash(user['password'], password):
        return jsonify({"msg": "Usuario o contraseña incorrectos"}), 401

    claims = {"role": user['role']}
    token = create_access_token(identity=username, additional_claims=claims)
    return jsonify(access_token=token, role=user['role']), 200
@app.route('/usuarios', methods=['POST'])
@role_required(['admin'])
def add_user():
    data = request.get_json()
    if not data or 'username' not in data or 'password' not in data or 'role' not in data:
        return jsonify({"msg": "Se requiere username, password y role"}), 400

    username = data['username']
    if username in users:
        return jsonify({"msg": "El usuario ya existe"}), 409

    role = data['role']
    if role not in ['client', 'manager', 'admin']:
        return jsonify({"msg": "Rol inválido"}), 400

    users[username] = {
        'password': generate_password_hash(data['password']),
        'role': role
    }
    return jsonify({"msg": "Usuario creado", "username": username, "role": role}), 201
@jwt.unauthorized_loader
def custom_unauthorized_response(callback):
    return jsonify({"msg": "Falta el encabezado de autorización"}), 401

@jwt.invalid_token_loader
def custom_invalid_token(reason):
    return jsonify({"msg": "Token inválido"}), 422