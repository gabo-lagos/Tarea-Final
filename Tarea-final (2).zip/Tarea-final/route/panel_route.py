from flask import Flask, app, jsonify, request, render_template
from tarea_app import juguetes_col
from tarea_app import juguetes
from tarea_app import db
@app.route('/panel')
def panel():
    try:
        juguetes_db = list(juguetes_col.find({}, {"_id": 0}))
    except Exception as e:
        print("⚠️ No se pudo conectar a MongoDB:", e)
        juguetes_db = juguetes  # usa la lista local
    return render_template("dashboard.html", juguetes=juguetes_db)