
from flask_jwt_extended import jwt_required
from flask import jsonify
from flask_jwt_extended import get_jwt
from tarea_app import app
from tarea_app import usuarios_col
from tarea_app import db
from tarea_app import users
from werkzeug.security import generate_password_hash, check_password_hash

users = {
    'alice': {'password': generate_password_hash('alicepass'), 'role': 'client'},
    'bob': {'password': generate_password_hash('bobpass'), 'role': 'manager'},
    'carol': {'password': generate_password_hash('carolpass'), 'role': 'admin'}
}

def role_required(allowed_roles):
    def wrapper(fn):
        @jwt_required()
        def decorator(*args, **kwargs):
            claims = get_jwt()
            role = claims.get('role')
            if role not in allowed_roles:
                return jsonify({"msg": "El usuario no tiene el rol requerido"}), 403
            return fn(*args, **kwargs)
        decorator.__name__ = fn.__name__
        return decorator
    return wrapper
@app.route('/reports', methods=['GET'])
@role_required(['manager', 'admin'])
def reports():
    return jsonify({"msg": "Datos de reporte confidenciales"}), 200
def run_basic_tests():
    print("Ejecutando pruebas básicas...")
    client = app.test_client()

    rv = client.post('/login', json={'username': 'carol', 'password': 'carolpass'})
    print('/login (carol) estado:', rv.status_code, 'respuesta:', rv.get_json())
    assert rv.status_code == 200
    token = rv.get_json().get('access_token')

    rv = client.post('/login', json={'username': 'carol', 'password': 'wrong'})
    print('/login contraseña incorrecta estado:', rv.status_code, 'respuesta:', rv.get_json())
    assert rv.status_code == 401

    rv = client.post('/juguetes', json={'nombre': 'X'})
    print('/juguetes sin token estado:', rv.status_code, 'respuesta:', rv.get_json())
    assert rv.status_code == 401

    rv = client.get('/reports', headers={'Authorization': 'Bearer invalid.token'})
    print('/reports token inválido estado:', rv.status_code, 'respuesta:', rv.get_json())
    assert rv.status_code == 422

    rv = client.post('/login', json={'username': 'alice', 'password': 'alicepass'})
    alice_token = rv.get_json().get('access_token')
    rv = client.delete('/juguetes/1', headers={'Authorization': f'Bearer {alice_token}'})
    print('/juguetes eliminar como alice estado:', rv.status_code, 'respuesta:', rv.get_json())
    assert rv.status_code == 403
@app.route('/migrar_usuarios')
@role_required(['admin'])
def migrar_usuarios():
    try:
        if db is None or usuarios_col is None:
            return jsonify({"msg": "MongoDB no está disponible"}), 503

        existentes = [u["username"] for u in usuarios_col.find({}, {"username": 1, "_id": 0})]
        nuevos = []

        for username, data in users.items():
            if username not in existentes:
                nuevos.append({
                    "username": username,
                    "password": data["password"],
                    "role": data["role"]
                })

        if not nuevos:
            return jsonify({"msg": "No hay nuevos usuarios para migrar"}), 200

        result = usuarios_col.insert_many(nuevos)
        print(f"Insertados {len(result.inserted_ids)} usuarios en MongoDB")
        return jsonify({"msg": f"Se migraron {len(result.inserted_ids)} usuarios a MongoDB"}), 201

    except Exception as e:
        import traceback
        print("Error al migrar usuarios:", e)
        traceback.print_exc()
        return jsonify({"msg": "Error al migrar usuarios", "error": str(e)}), 500
