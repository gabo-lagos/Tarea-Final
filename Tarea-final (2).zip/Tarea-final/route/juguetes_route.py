
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt
from tarea_app import app
from conection_with_mongo import db, juguetes_col
juguetes = [
    {
        "id": 1,
        "nombre": "Porsche 917LH",
        "categoria": "Carros",
        "edad_recomendada": "3+",
        "precio": 10000.0,
        "marca": "Hot Wheels"
    },
    {
        "id": 2,
        "nombre": "Aston Martin DB4GT",
        "categoria": "Carros",
        "edad_recomendada": "3+",
        "precio": 10000.0,
        "marca": "Hot Wheels"
    },
    {
        "id": 3,
        "nombre": "Hot Wheels NIGHTBURNERZ",
        "categoria": "Paquetes de carros",
        "edad_recomendada": "3+",
        "precio": 54900.0,
        "marca": "Hot Wheels"
    },
    {
        "id": 4,
        "nombre": "Monoplaza Ferrari F1",
        "categoria": "Carros a escala",
        "edad_recomendada": "6+",
        "precio": 20000.0,
        "marca": "LEGO"
    },
    {
        "id": 5,
        "nombre": "Pelota de futbol",
        "categoria": "Deportes",
        "edad_recomendada": "7+",
        "precio": 160000.0,
        "marca": "Adidas"
    }
]

juguetes_bp = Blueprint('juguetes_bp', __name__)
def role_required(allowed_roles):
    def wrapper(fn):
        @jwt_required()
        def decorator(*args, **kwargs):
            claims = get_jwt()
            role = claims.get('role')
            if role not in allowed_roles:
                return jsonify({"msg": "El usuario no tiene el rol requerido"}), 403
            return fn(*args, **kwargs)
        decorator.__name__ = fn.__name__
        return decorator
    return wrapper
@app.route('/juguetes', methods=['GET'])
def get_all_juguetes():
    
    categoria = request.args.get('categoria')
    marca = request.args.get('marca')

    resultados = juguetes
    if categoria:
        resultados = [j for j in resultados if j["categoria"].lower() == categoria.lower()]
    if marca:
        resultados = [j for j in resultados if j["marca"].lower() == marca.lower()]

    return jsonify(resultados)

@app.route('/juguetes', methods=['POST'])
@jwt_required()
def add_juguete():
    data = request.get_json()
    if not data:
        return jsonify({"msg": "Falta el cuerpo JSON"}), 400
    data["id"] = (juguetes[-1]['id'] + 1) if juguetes else 1
    juguetes.append(data)
    return jsonify(data), 201

@app.route('/juguetes/<int:id>', methods=['DELETE'])
@role_required(['manager', 'admin'])
def delete_juguete(id):
    global juguetes
    encontrado = [j for j in juguetes if j['id'] == id]
    if not encontrado:
        return jsonify({"error": "Juguete no encontrado"}), 404
    juguetes = [j for j in juguetes if j['id'] != id]
    return jsonify({"mensaje": f"Juguete con ID {id} eliminado"}), 200
@app.route('/migrar_juguetes')
def migrar_juguetes():
    from pprint import pprint
    try:
        print("Iniciando migración de juguetes...")

        if db is None or juguetes_col is None:
            print("La base de datos no está inicializada")
            return jsonify({"msg": "MongoDB no está disponible"}), 503

        print("Conectado a la base:", db.name)

        existentes = [doc.get("id") for doc in juguetes_col.find({}, {"id": 1, "_id": 0})]
        print(f"Juguetes existentes en Mongo: {existentes}")

        nuevos = [j for j in juguetes if j["id"] not in existentes]
        print(f"Juguetes nuevos para insertar: {len(nuevos)}")

        if not nuevos:
            return jsonify({"msg": "No hay nuevos juguetes para migrar"}), 200

        resultado = juguetes_col.insert_many(nuevos)
        print(f"Insertados {len(resultado.inserted_ids)} juguetes.")
        pprint(nuevos)
        return jsonify({"msg": f"Se migraron {len(resultado.inserted_ids)} juguetes a MongoDB"}), 201

    except Exception as e:
        import traceback
        print("Error al migrar juguetes:", e)
        traceback.print_exc()
        return jsonify({"msg": "Error al migrar", "error": str(e)}), 500