from flask import Flask, jsonify
import os
import sys
from conection_with_mongo.conection_MongoDB import db, client, app




@app.route('/', methods=['GET'])
def home():
    return jsonify({
        "mensaje": "API Flask JWT en ejecucion",
    }), 200
if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'test':
        pass
    else:
        if client:
            print(" Colecciones existentes:", db.list_collection_names())
        app.run(host='0.0.0.0',
                 port=8003, 
                 debug=False, 
                 use_reloader=False
            )


